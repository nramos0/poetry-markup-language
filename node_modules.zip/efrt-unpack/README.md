the **unpack** half of the [efrt library](npmjs.com/package/efrt).

See that repo for full documentation.

```bash
npm install efrt-unpack
```
```html
<script src="https://unpkg.com/efrt@latest/builds/efrt-unpack.min.js"></script>
<script>
  var trie=unpack(compressedStuff);
  trie.hasOwnProperty('miles davis');
</script>
```

MIT
